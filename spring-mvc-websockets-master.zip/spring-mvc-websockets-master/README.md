spring-mvc-websockets
===============

Code for http://kimrudolph.de/blog/spring-4-websockets-tutorial/
