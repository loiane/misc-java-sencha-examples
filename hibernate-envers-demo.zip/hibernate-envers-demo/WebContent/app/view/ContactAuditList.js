Ext.define('ExtMVC.view.ContactAuditList', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.contactaudit',

    iconCls: 'icon-grid',
    title: 'Contacts',
    store: 'ContactsAudit',

    initComponent: function() {
        var me = this;

        Ext.applyIf(me, {
            columns: [
{
    xtype: 'gridcolumn',
    width: 170,
    dataIndex: 'id',
    flex: 1,
    text: 'ID'
},
                {
                    xtype: 'gridcolumn',
                    width: 170,
                    dataIndex: 'name',
                    flex: 1,
                    text: 'NAME'
                },
                {
                    xtype: 'gridcolumn',
                    width: 160,
                    dataIndex: 'phone',
                    flex: 1,
                    text: 'PHONE #'
                },
                {
                    xtype: 'gridcolumn',
                    width: 170,
                    dataIndex: 'email',
                    flex: 1,
                    text: 'EMAIL'
                },
                {
                    xtype: 'gridcolumn',
                    width: 100,
                    dataIndex: 'revId',
                    text: 'Revision Id'
                },
                {
                    xtype: 'gridcolumn',
                    width: 100,
                    dataIndex: 'action',
                    text: 'Action'
                },
                {
                    xtype: 'gridcolumn',
                    width: 100,
                    dataIndex: 'revisionDate',
                    text: 'Date',
                    format:'Y-m-j'
                }
            ],
            dockedItems: [
                {
                    xtype: 'pagingtoolbar',
                    dock: 'top',
                    width: 360,
                    displayInfo: true,
                    emptyMsg: 'No contacts to display',
                    store: 'ContactsAudit'
                }
            ]
        });

        me.callParent(arguments);
    }

});