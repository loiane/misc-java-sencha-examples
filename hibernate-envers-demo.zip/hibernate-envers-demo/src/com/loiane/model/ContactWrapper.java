package com.loiane.model;

public class ContactWrapper {

	private Contact data;

	public Contact getData() {
		return data;
	}

	public void setData(Contact data) {
		this.data = data;
	}
	
}
