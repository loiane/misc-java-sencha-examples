package com.loiane.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.envers.DefaultRevisionEntity;
import org.hibernate.envers.RevisionType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.loiane.dao.ContactDAO;
import com.loiane.model.Contact;
import com.loiane.model.ContactAudit;

@Service
public class ContactService {
	
	private ContactDAO contactDAO;

	/**
	 * Get all contacts
	 * @return
	 */
	@Transactional(readOnly=true)
	public List<Contact> getContactList(int start, int limit){
		
		return contactDAO.getContacts(start, limit);
	}
	
	/**
	 * Create new Contact/Contacts
	 * @param data - json data from request
	 * @return created contacts
	 */
	@Transactional
	public List<Contact> create(Contact contact){
		
        List<Contact> newContacts = new ArrayList<Contact>();
		
		newContacts.add(contactDAO.saveContact(contact));
		
		return newContacts;
	}
	
	
	/**
	 * Update contact/contacts
	 * @param data - json data from request
	 * @return updated contacts
	 */
	@Transactional
	public List<Contact> update(Contact contact){
		
		List<Contact> returnContacts = new ArrayList<Contact>();
		
		returnContacts.add(contactDAO.saveContact(contact));
		
		return returnContacts;
	}
	
	/**
	 * Delete contact/contacts
	 * @param contact - json data from request
	 */
	@Transactional
	public void delete(Contact contact){
		
		contactDAO.deleteContact(contact.getId());
	}
	
	/**
	 * Get total of Contacts from database.
	 * Need to set this value on ExtJS Store
	 * @return
	 */
	public int getTotalContacts(){

		return contactDAO.getTotalContacts();
	}

	/**
	 * Spring use - DI
	 * @param contactDAO
	 */
	@Autowired
	public void setContactDAO(ContactDAO contactDAO) {
		this.contactDAO = contactDAO;
	}
	
	public List<ContactAudit> getAuditInfo(){
		List<Object[]> auditList = contactDAO.getAuditInfo();
		List<ContactAudit> list = new ArrayList<ContactAudit>();
		
		Object[] l;
		Contact c;
		DefaultRevisionEntity e;
		RevisionType t;
		ContactAudit audit;
		
		for (Object o : auditList){
			l = (Object[]) o;
			c = (Contact) l[0];
			e = (DefaultRevisionEntity) l[1];
			t = (RevisionType) l[2];
			
			audit = new ContactAudit();
			audit.setId(c.getId());
			audit.setEmail(c.getEmail());
			audit.setName(c.getName());
			audit.setPhone(c.getPhone());
			audit.setAction(t.toString());
			audit.setRevisionDate(e.getRevisionDate());
			audit.setRevId(e.getId());
			
			list.add(audit);
		}
		
		return list;
	}
	
}
