Ext.define('Citi.view.Main', {
    extend: 'Ext.window.Window',
    requires:[
        'Ext.layout.container.Border',
        'Citi.view.ChatView'
    ],
    
    alias: 'widget.main',

    autoShow: true,
    width: 600,
    height: 440,

    layout: {
        type: 'border'
    },

    items: [{
        region: 'south',
        title: '',
        height: 150,
        split: true,
        xtype: 'form',
        itemId: 'formChat',
        layout: {
            type: 'hbox',
            align: 'stretch'
        },
        items: [{
            xtype: 'textareafield',
            flex: 1
        },{
            xtype: 'button',
            itemId: 'sendBtn',
            text: 'Send',
            width: 50,
            disabled: true
        }]
    },{
        region: 'center',
        xtype: 'chatview',
        itemId: 'chatArea'
    }]
});