Ext.define('Citi.controller.Main', {
    extend: 'Ext.app.Controller',

   request : {},
   subSocket: {},

    onWindowShow: function (button, e, options) {

        var me = this;

        var myName = false;
        var author = null;
        var logged = false;
        var socket = $.atmosphere;

        // We are now ready to cut the request
        me.request = { url: document.location.toString() + 'chat.action',
            contentType : "application/json",
            logLevel : 'debug',
            transport : 'websocket' ,
            fallbackTransport: 'long-polling'
        };

        me.request.onOpen = function(response) {
            Ext.Msg.prompt('Name', 'Please enter your name:', function(btn, text){
                if (btn == 'ok'){
                    Ext.ComponentQuery.query('main form#formChat')[0].setTitle(text);
                    Ext.ComponentQuery.query('main button#sendBtn')[0].setDisabled(false);
                }
            });
        };

        me.request.onTransportFailure = function(errorMsg, request) {
            jQuery.atmosphere.info(errorMsg);
            if ( window.EventSource ) {
                request.fallbackTransport = "sse";
            }
        };

        me.request.onReconnect = function (request, response) {
            socket.info("Reconnecting");
        };

        me.request.onMessage = function (response) {
            var message = response.responseBody,
                chatArea = Ext.ComponentQuery.query('chatview')[0],
                store = chatArea.getStore();


            try {
                var json = jQuery.parseJSON(message);
            } catch (e) {
                console.log('This doesn\'t look like a valid JSON: ', message.data);
                return;
            }

            if (!logged) {
                logged = true;

                //status.text(myName + ': ').css('color', 'blue');
                //input.removeAttr('disabled').focus();
            } else {
                //input.removeAttr('disabled');

                var me = json.author == author;
                var date = typeof(json.time) == 'string' ? parseInt(json.time) : json.time;
                var datetime = new Date(date);
                var dateString = (datetime.getHours() < 10 ? '0' + datetime.getHours() : datetime.getHours()) + ':'
                    + (datetime.getMinutes() < 10 ? '0' + datetime.getMinutes() : datetime.getMinutes());
                store.add({user: json.author, msg: json.text, date: dateString});
                //addMessage(json.author, json.text, me ? 'blue' : 'black', new Date(date));
            }
        };

        me.request.onClose = function(response) {
            logged = false;
        };

        me.request.onError = function(response) {
            console.log('Sorry, but there\'s some problem with your socket or the server is down');
        };

        me.subSocket = socket.subscribe(me.request);
    },

    onButtonClick: function (button, e, options) {

        var me = this;
    	var form = button.up('form'),
    		textArea = form.down('textareafield'),
    		chatArea = button.up('window').down('chatview'),
    		store = chatArea.getStore();	  

        var datetime = new Date();
        var dateString = (datetime.getHours() < 10 ? '0' + datetime.getHours() : datetime.getHours()) + ':'
            + (datetime.getMinutes() < 10 ? '0' + datetime.getMinutes() : datetime.getMinutes());  	

    	//store.add({user: form.title, msg: textArea.getValue(), date: dateString});

        me.subSocket.push(jQuery.stringifyJSON({ author: form.title, message: textArea.getValue() }));
    	
    	textArea.reset();	

    	//store.sync();
    },

    init: function(application) {
	    this.control({
            "main": {
                show: this.onWindowShow
            },
	        "main button#sendBtn": {
	            click: this.onButtonClick
	        }
	    });
	}
});
