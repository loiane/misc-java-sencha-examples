Ext.define('Citi.Application', {
    name: 'Citi',

    extend: 'Ext.app.Application',

    views: [
        // TODO: add views here
    ],

    controllers: [
        'Main'
    ],

    stores: [
        // TODO: add stores here
    ],

    launch: function(){
        //Ext.ComponentQuery.query('main')[0].show();
    }
});
