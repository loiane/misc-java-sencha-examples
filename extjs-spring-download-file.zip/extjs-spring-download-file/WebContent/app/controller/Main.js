Ext.define('App.controller.Main', {
    extend: 'Ext.app.Controller',

    init: function(application) {
        this.control({
            "button#downloadDocument": {
                click: this.onButtonClickSubmit
            }
        });
    },

    onButtonClickSubmit: function(){

    	var mainPanel = Ext.ComponentQuery.query('panel#centerPanel')[0];

    	mainPanel.add({
            xtype: 'panel',
            region: 'east',
            width: (mainPanel.getWidth() / 2),
            split: true,
            collapsible: true,
            closable: true,
            iconCls: 'pdf',
            title: 'View Document',
            layout: 'fit',
            html: 'loading PDF...',
            items: [{
                xtype: 'uxiframe',
                src: 'file/download.action'
            }]
        }); 
    }  
});
