Ext.define('App.view.Main', {
    extend: 'Ext.container.Container',
    requires:[
        'Ext.tab.Panel',
        'Ext.layout.container.Border'
    ],
    
    xtype: 'app-main',

    layout: {
        type: 'border'
    },

    items: [{
        region: 'west',
        xtype: 'panel',
        title: 'west',
        width: 150,
        dockedItems: [{
            xtype: 'toolbar',
            dock: 'top',
            items: [{
                text: 'Download Document',
                itemId: 'downloadDocument'
            }]
        }]
    },{
        region: 'center',
        xtype: 'panel',
        itemId: 'centerPanel',
        layout: 'border',
        items:[
            Ext.create('Ext.form.Panel', {
                region: 'center',
                title: 'Document Info',
                bodyPadding: 5,
                width: 350,

                layout: 'anchor',
                defaults: {
                    anchor: '100%'
                },

                // The fields
                defaultType: 'textfield',
                items: [{
                    fieldLabel: 'First Name',
                    name: 'first',
                    allowBlank: false
                },{
                    fieldLabel: 'Last Name',
                    name: 'last',
                    allowBlank: false
                }]
            })
        ]    
    }]
});