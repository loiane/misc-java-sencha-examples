Ext.define('JavaOne.view.Viewport', {
    extend: 'Ext.container.Viewport'
});