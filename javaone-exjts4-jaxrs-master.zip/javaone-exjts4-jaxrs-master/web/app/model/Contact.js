Ext.define('JavaOne.model.Contact', {
    extend: 'Ext.data.Model',
    fields: ['id', 'name', 'phone', 'email']
});