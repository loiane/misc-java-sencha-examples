/*

This file is part of Ext JS 4

Copyright (c) 2011 Sencha Inc

Contact:  http://www.sencha.com/contact

GNU General Public License Usage
This file may be used under the terms of the GNU General Public License version 3.0 as published by the Free Software Foundation and appearing in the file LICENSE included in the packaging of this file.  Please review the following information to ensure the GNU General Public License version 3.0 requirements will be met: http://www.gnu.org/copyleft/gpl.html.

If you are unsure which license is appropriate for your use, please contact the sales department at http://www.sencha.com/contact.

*/
/* DO NO EDIT THIS FILE MANUALLY IT IS GENERATED AUTOMATICALLY BY ../build/build.sh */
 this.ExtSpecs = ['spec/class/Class.js','spec/class/ClassManager.js','spec/Date.js','spec/dom/Element.insertion.js','spec/dom/Element.js','spec/dom/Element.static.js','spec/dom/Element.traversal.js','spec/EventManager.js','spec/Ext-more.js','spec/Ext.js','spec/lang/Array.js','spec/lang/Error.js','spec/lang/Function.js','spec/lang/Number.js','spec/lang/Object.js','spec/lang/String.js','spec/misc/JSON.js','spec/Support.js','spec/util/Format.js','spec/version/Version.js'];

