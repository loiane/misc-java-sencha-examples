package com.loiane.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.atmosphere.cpr.AtmosphereRequest;
import org.atmosphere.cpr.AtmosphereResource;
import org.atmosphere.cpr.AtmosphereResource.TRANSPORT;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.loiane.model.Contact;
import com.loiane.service.ContactService;
import com.loiane.util.ExtJSReturn;


@Controller
@RequestMapping(value = "contact.action")
public class ContactController  {

	private ContactService contactService;
	
	private final String READ_EVENT = "read";
	private final String CREATE_EVENT = "create";
	private final String UPDATE_EVENT = "update";
	private final String DELETE_EVENT = "destroy";
	private final String EVENT = "event";
	private final String DATA = "data";
	
	@ResponseBody
	@RequestMapping(method = RequestMethod.GET)
	public void onRequest(AtmosphereResource r) throws IOException {
		AtmosphereRequest req = r.getRequest();
		
		if (req.getHeader("negotiating") == null) {
			r.resumeOnBroadcast(r.transport() == TRANSPORT.LONG_POLLING).suspend();
		} else {
			r.getResponse().getWriter().write("OK");
		}
	}
	
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(method = RequestMethod.POST)
	public void post(AtmosphereResource r) throws Exception {
		AtmosphereRequest req = r.getRequest();
		
		String body = req.getReader().readLine().trim();
		System.out.println(body);
		
		JSONObject o = JSONObject.fromObject(body);
		String event = o.getString(EVENT);
		
		System.out.println(event);
		
		Map<String,? extends Object> extjsReturn;
		JSONObject contacts = null;
		
		if (event.equalsIgnoreCase(READ_EVENT)){
			
			JSONObject data = (JSONObject) o.get(DATA);
			int limit = Integer.parseInt(data.getString("limit"));
			int start =  Integer.parseInt(data.getString("start"));
			
			System.out.println(limit);
			System.out.println(start);
			
			extjsReturn = view(start,limit);
			
			contacts = JSONObject.fromObject(extjsReturn);
			
			
		} else if (event.equalsIgnoreCase(CREATE_EVENT)){
			
			JSONArray data = (JSONArray) o.get(DATA);
			List<Contact> list = JSONArray.toList(data, Contact.class);
			extjsReturn = create(list);
			
			contacts = JSONObject.fromObject(extjsReturn);
			
		} else if (event.equalsIgnoreCase(UPDATE_EVENT)){
			
			JSONArray data = (JSONArray) o.get(DATA);
			List<Contact> list = JSONArray.toList(data, Contact.class);
			extjsReturn = update(list);
			
			contacts = JSONObject.fromObject(extjsReturn);
			
		} else if (event.equalsIgnoreCase(DELETE_EVENT)){
			
			JSONArray data = (JSONArray) o.get(DATA);
			List<Contact> list = JSONArray.toList(data, Contact.class);
			extjsReturn = delete(list);
			
			contacts = JSONObject.fromObject(extjsReturn);
		}
		
		System.out.println(contacts.toString());
		
		r.getBroadcaster().broadcast(contacts.toString());
	}
	
	private Map<String,? extends Object> view(int start, int limit) throws Exception {

		try{

			List<Contact> contacts = contactService.getContactList(start,limit);
			
			int total = contactService.getTotalContacts();

			return ExtJSReturn.mapOK(contacts, total, READ_EVENT);

		} catch (Exception e) {

			return ExtJSReturn.mapError("Error retrieving Contacts from database.");
		}
	}
	
	private Map<String,? extends Object> create(List<Contact> data) throws Exception {

		try{

			List<Contact> contacts = contactService.create(data);

			return ExtJSReturn.mapOK(contacts, CREATE_EVENT);

		} catch (Exception e) {

			return ExtJSReturn.mapError("Error trying to create contact.");
		}
	}
	
	public Map<String,? extends Object> update(List<Contact> data) throws Exception {
		try{

			List<Contact> contacts = contactService.update(data);

			return ExtJSReturn.mapOK(contacts, UPDATE_EVENT);

		} catch (Exception e) {

			return ExtJSReturn.mapError("Error trying to update contact.");
		}
	}
	
	public Map<String,? extends Object> delete(List<Contact> data) throws Exception {
		
		try{
			
			contactService.delete(data);
			
			return ExtJSReturn.mapOK(data, DELETE_EVENT);

		} catch (Exception e) {

			return ExtJSReturn.mapError("Error trying to delete contact.");
		}
	}
	

	@Autowired
	public void setContactService(ContactService contactService) {
		this.contactService = contactService;
	}

}
