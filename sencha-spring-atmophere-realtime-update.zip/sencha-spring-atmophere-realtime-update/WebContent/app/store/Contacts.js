Ext.define('ExtMVC.store.Contacts',{
	extend: 'Ext.data.Store',

	model: 'ExtMVC.model.Contact',

	pageSize: 20,

	storeId: 'ExtMVC.store.Contacts',

	proxy: {
		type: 'atmospherewebsocket',
		//url: 'php/listaContatos.php',

		url: 'contact.action',

		storeId: 'ExtMVC.store.Contacts',

		reader: {
			type: 'json',
			root: 'data'
		},

		writer: {
			type: 'json',
			root: 'data',
			encode: false
		}
	}
});