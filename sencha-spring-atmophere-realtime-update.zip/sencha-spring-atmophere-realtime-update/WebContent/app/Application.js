Ext.Loader.setConfig({
    enabled: true,
    paths: {
        'Ext.ux': 'plugins'
    }
});

Ext.require(['Ext.ux.data.proxy.AtmosphereWebSocket']);

Ext.define('ExtMVC.Application', {
    name: 'ExtMVC',

    extend: 'Ext.app.Application',

    requires: [
    	'Ext.toolbar.Paging',
        'Ext.form.Panel',
        'Ext.layout.container.Border',
        'Ext.form.field.Hidden'
    ],

    views: [
        
    ],

    controllers: [
        'Main'
    ],

    stores: [
        'Contacts'
    ]
});
