Ext.define('ExtMVC.view.ContactsForm',{
	extend: 'Ext.form.Panel',
	alias: 'widget.contactsform',

	//iconCls: 'icon-user',
	title: 'Contacts',
	bodyPadding: 10,
	defaults: {
		anchor: '100%'
	},

	items: [
		{
			xtype: 'hiddenfield',
	        name: 'id'
		},
		{
			xtype: 'textfield',
	        name: 'name',
	        fieldLabel: 'Name'
		},
		{
			xtype: 'textfield',
	        name: 'email',
	        fieldLabel: 'Email'
		},
		{
			xtype: 'textfield',
	        name: 'phone',
	        fieldLabel: 'Phone'
		}
	],
	dockedItems: [
		{
			xtype: 'toolbar',
			dock: 'bottom',
			layout: {
				type: 'hbox',
				pack: 'start'
			},
			items: [
				{
					xtype: 'button',
					text: 'Create',
					itemId: 'add',
					iconCls: 'icon-add'
				},
				{
					xtype: 'button',
					text: 'Save',
					itemId: 'save',
					iconCls: 'icon-save'
				},
				{
					xtype: 'button',
					text: 'Delete',
					itemId: 'delete',
					iconCls: 'icon-delete'
				}
			]
		}
	]
});