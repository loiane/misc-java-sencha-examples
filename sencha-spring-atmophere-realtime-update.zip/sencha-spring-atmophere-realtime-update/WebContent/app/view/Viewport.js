Ext.define('ExtMVC.view.Viewport', {
    extend: 'Ext.container.Viewport',
    requires:[
        'Ext.layout.container.Fit',
        'ExtMVC.view.ContactsGrid',
        'ExtMVC.view.ContactsForm'
    ],

    layout: {
        type: 'border'
    },

    items: [{
        region: 'center',
        xtype: 'contactsgrid'
    },{
        xtype: 'contactsform',
        region: 'north',
        height: 150
    }]
});
