Ext.define('Citi.view.ChatView', {
    extend: 'Ext.view.View',
    alias: 'widget.chatview',

    padding: 10,

    title: 'Online Help - Chat',

    style: 'background-color: #FFF',

    tpl: new Ext.XTemplate (
        '<tpl for=".">',
            '<div style="margin-bottom: 5px;" class="thumb-wrap">',
            '<span><b>{user}</b></span> @ ',
            '<span>{date}: </span>',
            '<span>{msg}</span>',
            '</div>',
        '</tpl>'
    ),

    itemSelector: 'div.thumb-wrap',

    store: Ext.create('Ext.data.Store',{
        proxy: {
            type: 'memory',
            reader: {
                type: 'json',
                root: 'data'
            }
        },
        fields: ['user', 'msg', 'date']
    })
});