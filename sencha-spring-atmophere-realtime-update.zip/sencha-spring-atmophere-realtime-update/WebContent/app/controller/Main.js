Ext.define('ExtMVC.controller.Main', {
    extend: 'Ext.app.Controller',

    models: [
    	'ExtMVC.model.Contact'
    ],

    stores: [
    	'ExtMVC.store.Contacts'
    ],

    views: [
    	'ExtMVC.view.ContactsGrid',
        'ExtMVC.view.ContactsForm'
    ],

    init: function(application){
        this.control({
            "contactsgrid": {
                render : this.onGridRender,
                selectionchange: this.onGridSelectionChange
            },
            "contactsform button#add": {
                click : this.onAddClick
            },
                        
            "contactsform button#delete": {
                click : this.onDeleteClick
            },
            "contactsform button#save": {
                click : this.onSaveClick
            }
        });
    },

    onGridRender: function(grid, eOpts){
        grid.getStore().load();
    },

    onGridSelectionChange: function(grid, selected, eOpts ){

        if (selected){
            var record = selected[0],
            form = Ext.ComponentQuery.query('contactsform')[0];

            if (record)
                form.loadRecord(record);
        }
    },

    onAddClick: function(btn, e, eOpts ){
        
        btn.up('form').getForm().reset();
    },

    onDeleteClick: function(btn, e, eOpts){

        var grid = Ext.ComponentQuery.query('contactsgrid')[0],
            records = grid.getSelectionModel().getSelection(),
            store = grid.getStore();

        store.remove(records[0]);

        store.sync();
    },

    onSaveClick: function(btn, e, eOpts){

        var form = btn.up('form'),
            values = form.getValues(),
            record = form.getRecord(),
            grid = Ext.ComponentQuery.query('contactsgrid')[0],
            store = grid.getStore();

        if (record){ //edicao
            
            record.set(values);

        } else { //novo registro 

            var contact = Ext.create('ExtMVC.model.Contact',{
                name: values.name,
                phone: values.phone,
                email: values.email
            });

            store.insert(0,contact);
        }

        store.sync();
    }    
});
