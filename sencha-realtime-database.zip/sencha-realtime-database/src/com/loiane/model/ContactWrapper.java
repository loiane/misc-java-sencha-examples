package com.loiane.model;

import java.util.List;

public class ContactWrapper {

	private List<Contact> data;

	public List<Contact> getData() {
		return data;
	}

	public void setData(List<Contact> data) {
		this.data = data;
	}
	
}
