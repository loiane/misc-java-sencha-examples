package com.loiane.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loiane.dao.ContactDAO;
import com.loiane.model.Configs;
import com.loiane.model.Contact;


@Service
public class ContactService {
	
	private ContactDAO contactDAO;
	
	public String getRealTimeConfig(){
		
		List<Configs> configs = contactDAO.getRealTimeConfig();
		
		return ( configs.size() > 0) ? configs.get(0).getPhone() : "N";
	}
	
	/**
	 * Get all contacts
	 * @return
	 */
	public List<Contact> getContactList(int start, int limit){
		
		return contactDAO.getContacts(start, limit);
	}
	
	/**
	 * Create new Contact/Contacts
	 * @param data - json data from request
	 * @return created contacts
	 */
	public List<Contact> create(List<Contact> contacts){
		
        List<Contact> newContacts = new ArrayList<Contact>();
        
        for (Contact contact :contacts){
        	newContacts.add(contactDAO.saveContact(contact));
		}
		
		return newContacts;
	}
	
	
	/**
	 * Update contact/contacts
	 * @param data - json data from request
	 * @return updated contacts
	 */
	public List<Contact> update(List<Contact> contacts){
		
		List<Contact> returnContacts = new ArrayList<Contact>();
		
		for (Contact contact :contacts){
			returnContacts.add(contactDAO.saveContact(contact));
		}
		
		return returnContacts;
	}
	
	/**
	 * Delete contact/contacts
	 * @param contact - json data from request
	 */
	public void delete(List<Contact> contacts){
		
		for (Contact contact :contacts){
			contactDAO.deleteContact(contact.getId());
		}
	}
	
	/**
	 * Get total of Contacts from database.
	 * Need to set this value on ExtJS Store
	 * @return
	 */
	public int getTotalContacts(){

		return contactDAO.getTotalContacts();
	}

	/**
	 * Spring use - DI
	 * @param contactDAO
	 */
	@Autowired
	public void setContactDAO(ContactDAO contactDAO) {
		this.contactDAO = contactDAO;
	}
	
}
