Ext.define('ExtMVC.controller.Main', {
    extend: 'Ext.app.Controller',

    models: [
    	'ExtMVC.model.Contact'
    ],

    stores: [
    	'ExtMVC.store.Contacts'
    ],

    views: [
    	'ExtMVC.view.ContactsGrid',
        'ExtMVC.view.ContactsForm'
    ],

    init: function(application){
        this.control({
            "contactsgrid": {
                render : this.onGridRender
            },
            'contactsgrid dataview': {
                itemdblclick: this.editUser
            },
            'contactsgrid button#add': {
                click: this.addUser
            },
            'contactsgrid button#delete': {
                click: this.deleteUser
            },
            'contactsform button#save': {
                click: this.updateUser
            }
        });
    },

    onGridRender: function(grid, eOpts){

        var reader = {
            type: 'json',
            root: 'data'
        };

        var writer = {
            type: 'json',
            root: 'data',
            encode: false,
            allowSingle: false
        };

        var realTimeProxy = {
            type: 'atmospherewebsocket',
            url: 'contact.action',
            storeId: 'ExtMVC.store.Contacts',
            reader: reader,
            writer: writer
        };

        if (ExtMVC.model.Contact.realTime){
            grid.getStore().setProxy(realTimeProxy);
            grid.getStore().load();
        }

        grid.getStore().load();

    },

    addUser: function() {
        var edit = Ext.create('ExtMVC.view.ContactsForm').show();
    },

    editUser: function(grid, record) {
        var edit = Ext.create('ExtMVC.view.ContactsForm').show();

        if(record){
            edit.down('form').loadRecord(record);
        }
    },
    
    updateUser: function(button) {
        var win    = button.up('window'),
            form   = win.down('form'),
            record = form.getRecord(),
            values = form.getValues(),
            store = Ext.ComponentQuery.query('contactsgrid')[0].getStore();
        
        
        if (values.id > 0){
            record.set(values);
        } else{
            record = Ext.create('ExtMVC.model.Contact');
            record.set(values);
            record.setId(0);
            store.add(record);
        }
        
        win.close();
        store.sync();
    },
    
    deleteUser: function(button) {
        
        var grid = Ext.ComponentQuery.query('contactsgrid')[0],
        record = grid.getSelectionModel().getSelection(), 
        store = grid.getStore();

        store.remove(record);
        store.sync();
    }
});
