Ext.define('ExtMVC.store.Contacts',{
	extend: 'Ext.data.Store',

	model: 'ExtMVC.model.Contact',

	pageSize: 20,

	storeId: 'ExtMVC.store.Contacts',

	proxy: {
		type: 'ajax',

		api: {
        	read : 'contact/view.action',
            create : 'contact/create.action',
            update: 'contact/update.action',
            destroy: 'contact/delete.action'
        },

		storeId: 'ExtMVC.store.Contacts',

		reader: {
			type: 'json',
			root: 'data'
		},

		writer: {
			type: 'json',
			root: 'data',
			encode: false,
			allowSingle: false
		}
	}
});