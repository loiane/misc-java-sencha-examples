Ext.define('ExtMVC.view.ContactsGrid',{
	extend: 'Ext.grid.Panel',
	alias: 'widget.contactsgrid',

	store: 'ExtMVC.store.Contacts',

	//title: 'Contacts',

	//iconCls: 'icon-grid',

	columns: [
		{
			text: 'ID',
			width: 35,
			dataIndex: 'id'
		},
		{
			text: 'Name',
			width: 170,
			flex: 1,
			dataIndex: 'name'
		},
		{
			text: 'Phone',
			width: 100,
			dataIndex: 'phone'
		},
		{
			text: 'Email',
			width: 170,
			dataIndex: 'email'
		}
	],

	dockedItems: [
		{
            xtype: 'toolbar',
            items: [{
                iconCls: 'icon-save',
                itemId: 'add',
                text: 'Add',
                action: 'add'
            },{
                iconCls: 'icon-delete',
                itemId: 'delete',
                text: 'Delete',
                action: 'delete'
            }]
        },
		{
			xtype: 'pagingtoolbar',
	        store: 'ExtMVC.store.Contacts',
	        dock: 'top',
	        displayInfo: true,
	        emptyMsg: 'No contact found'
		}
	]

});















