Ext.Loader.setConfig({
    enabled: true,
    paths: {
        'Ext.ux': 'plugins'
    }
});

Ext.require(['Ext.ux.data.proxy.AtmosphereWebSocket']);

Ext.define('ExtMVC.Application', {
    name: 'ExtMVC',

    extend: 'Ext.app.Application',

    requires: [
    	'Ext.toolbar.Paging',
        'Ext.form.Panel',
        'Ext.layout.container.Border',
        'Ext.form.field.Hidden',
        'ExtMVC.model.Contact',
        'ExtMVC.view.Viewport'
    ],

    views: [
        
    ],

    controllers: [
        'Main'
    ],

    stores: [
        'Contacts'
    ],

    realTime: null,

    launch: function(){
        Ext.Ajax.request({
            url: 'config/getRealTimeConfig.action',
            success: function(response){
                var text = response.responseText;
                if (text === 'Y'){
                    ExtMVC.model.Contact.realTime = true;
                } else {
                    ExtMVC.model.Contact.realTime = false;
                }

                Ext.create('ExtMVC.view.Viewport');
            }
        });
    }
});
