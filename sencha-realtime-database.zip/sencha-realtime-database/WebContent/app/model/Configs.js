Ext.define('ExtMVC.model.Contact',{
	singleton: true,

	realTime: null
});