Ext.define('App.controller.Main', {
    extend: 'Ext.app.Controller'
});
