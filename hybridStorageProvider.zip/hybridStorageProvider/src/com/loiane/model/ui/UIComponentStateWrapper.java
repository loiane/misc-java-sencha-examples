package com.loiane.model.ui;

import java.util.List;

public class UIComponentStateWrapper {

	private List<UIComponentState> data;

	public List<UIComponentState> getData() {
		return data;
	}

	public void setData(List<UIComponentState> data) {
		this.data = data;
	}
}
